document.getElementById('acceptButton').addEventListener('click', function() {
    alert('你是傻蛋！');
});